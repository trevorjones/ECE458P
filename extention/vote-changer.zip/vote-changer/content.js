window.onload = function() {
	toggle(false)
}

chrome.extension.onMessage.addListener(function(message, sender, sendResponse) {
    toggle(message)
});

var toggle = function(changeVotes){
    if (changeVotes){
	    console.log("Change");
    } else {
    	console.log("Normal");
    }
}